local mod	= DBM:NewMod("Putricide", "DBM-Icecrown", 2)
local L		= mod:GetLocalizedStrings()

local GetTime = GetTime
local format = string.format

mod:SetRevision("20241116144454")
mod:SetCreatureID(36678)
mod:SetUsedIcons(1, 2, 3, 4)
mod:SetHotfixNoticeRev(20230827000000)
mod:SetMinSyncRevision(20230712000000)

mod:RegisterCombat("combat")

mod:RegisterEventsInCombat(
	"SPELL_CAST_START 70351 71966 71967 71968 71617 72842 72843 72851 72852 71621 72850 70672 72455 72832 72833 73121 73122 73120 71893",
	"SPELL_CAST_SUCCESS 70341 71255 72855 72856 70911 72615 72295 74280 74281",
	"SPELL_AURA_APPLIED 70447 72836 72837 72838 70672 72455 72832 72833 72451 72463 72671 72672 70542 70539 72457 72875 72876 70352 74118 70353 74119 72855 72856 70911",
	"SPELL_AURA_APPLIED_DOSE 72451 72463 72671 72672 70542",
	"SPELL_AURA_REFRESH 70539 72457 72875 72876 70542",
	"SPELL_AURA_REMOVED 70447 72836 72837 72838 70672 72455 72832 72833 72855 72856 70911 71615 70539 72457 72875 72876 70542",
	"SPELL_SUMMON 70342",
	"CHAT_MSG_MONSTER_YELL",
	"CHAT_MSG_RAID_BOSS_EMOTE",
	"UNIT_HEALTH"
)

-- General
local berserkTimer					= mod:NewBerserkTimer(600)

-- buffs from "Drink Me"
local timerMutatedSlash				= mod:NewTargetTimer(20, 70542, nil, false, nil, 5, nil, DBM_COMMON_L.TANK_ICON)
local timerRegurgitatedOoze			= mod:NewTargetTimer(20, 70539, nil, nil, nil, 5, nil, DBM_COMMON_L.TANK_ICON)

-- Stage One
mod:AddTimerLine(DBM_CORE_L.SCENARIO_STAGE:format(1)..": 100% – 80%")
local warnSlimePuddle				= mod:NewSpellAnnounce(70341, 2)
local warnUnstableExperimentSoon	= mod:NewSoonAnnounce(70351, 3)
local warnUnstableExperiment		= mod:NewSpellAnnounce(70351, 4)
local warnVolatileOozeAdhesive		= mod:NewTargetNoFilterAnnounce(70447, 3)
local warnGaseousBloat				= mod:NewTargetNoFilterAnnounce(70672, 3)
local warnUnboundPlague				= mod:NewTargetNoFilterAnnounce(70911, 3, nil, false, nil, nil, nil, true)		-- Heroic Ability, sound muted

local specWarnVolatileOozeAdhesive	= mod:NewSpecialWarningYou(70447, nil, nil, nil, 1, 2)
local specWarnVolatileOozeAdhesiveT	= mod:NewSpecialWarningMoveTo(70447, nil, nil, nil, 1, 2)
local specWarnGaseousBloat			= mod:NewSpecialWarningRun(70672, nil, nil, nil, 4, 2)
local specWarnGaseousBloatCast		= mod:NewSpecialWarningMove(72833, nil, nil, nil, 1, 2)		-- Gaseous Bloat (cast)
local specWarnUnboundPlague			= mod:NewSpecialWarningYou(70911, nil, nil, nil, 1, 2, 3)	-- Heroic Ability
local yellUnboundPlague				= mod:NewYellMe(70911, false)	-- Heroic Ability, disabled by default to reduce chat bubble spam

local timerGaseousBloat				= mod:NewTargetTimer(20, 70672, nil, nil, nil, 3)			-- Duration of debuff
local timerGaseousBloatCast			= mod:NewCastTimer(3, 70672, nil, nil, nil, 3)				-- Cast duration
local timerSlimePuddleCD			= mod:NewCDTimer(31.96, 70341, nil, nil, nil, 5, nil, DBM_COMMON_L.TANK_ICON, true) -- With variance below. P3 has lower timers. Added "keep" arg. (logs below in allTimers) - SPELL_SUMMON: "Charco de baba-70342
local timerUnstableExperimentCD		= mod:NewCDTimer(35, 70351, nil, nil, nil, 1, nil, DBM_COMMON_L.DEADLY_ICON, true) -- 5s variance [35-40]. Added "keep" arg (Bennu: 25H [2023-06-15]@[21:57:26] || 25H [2023-07-20]@[21:54:29] || 25H [2023-07-27]@[21:54:34]) - "Experimento inestable-71968-npc:36678-1314047 = pull:30.6/Stage 1/30.6, Stage 1.5/79.5, 5.9/85.4, 36.3, 39.7, 37.4" || "Experimento inestable-71968-npc:36678-802608 = pull:31.2/Stage 1/31.2, Stage 1.5/24.0, Stage 2/51.2, 11.5/62.7/86.7, 37.7, Stage 2.5/28.3, Stage 3/46.2" || "Experimento inestable-71967-npc:36678-1430387 = pull:32.3/Stage 1/32.3, Stage 1.5/75.8, 10.4/86.2, 38.7, Stage 2/90.4"
local timerUnboundPlagueCD			= mod:NewNextTimer(109, 70911, nil, nil, nil, 3, nil, DBM_COMMON_L.HEROIC_ICON) -- REVIEW! 109 increments, but keeps ticking to 169 or 218? (Bennu: 25H [2023-07-20]@[21:54:29] || 25H [2023-07-27]@[21:54:34]) -"Peste desatada-72856-npc:36678-802608 = pull:20.0/Stage 1/20.0, Stage 1.5/35.2, Stage 2/51.2, Stage 2.5/77.5, Stage 3/46.2, TooManyStages/7.9/218.0" || pull:20.0/Stage 1/20.0, Stage 1.5/36.4, Stage 2/52.2, 20.4/72.5/109.0, Stage 2.5/100.7, Stage 3/44.8, 23.6/68.4/169.0"
local timerUnboundPlague			= mod:NewBuffActiveTimer(12, 70911, nil, nil, nil, 3)		-- Heroic Ability: we can't keep the debuff 60 seconds, so we have to switch at 12-15 seconds. Otherwise the debuff does to much damage!

local soundSlimePuddle				= mod:NewSound(70341)

mod:AddSetIconOption("OozeAdhesiveIcon", 70447, true, 0, {4})--green icon for green ooze
mod:AddSetIconOption("GaseousBloatIcon", 70672, true, 0, {2})--Orange Icon for orange/red ooze
mod:AddSetIconOption("UnboundPlagueIcon", 70911, true, 0, {3})

-- Stage Two
mod:AddTimerLine(DBM_CORE_L.SCENARIO_STAGE:format(2)..": 80% – 35%")
local warnPhase2					= mod:NewPhaseAnnounce(2, 2, nil, nil, nil, nil, nil, 2)
local warnChokingGasBombSoon		= mod:NewPreWarnAnnounce(71255, 5, 3, nil, "Melee")
local warnChokingGasBomb			= mod:NewSpellAnnounce(71255, 3, nil, "Melee")		-- Phase 2 ability

--local specWarnMalleableGoo			= mod:NewSpecialWarningYou(72295, nil, nil, nil, 1, 2)
--local yellMalleableGoo				= mod:NewYellMe(72295)
--local specWarnMalleableGooNear		= mod:NewSpecialWarningClose(72295, nil, nil, nil, 1, 2)
local specWarnChokingGasBomb		= mod:NewSpecialWarningMove(71255, "Melee", nil, nil, 1, 2)
local specWarnMalleableGooCast		= mod:NewSpecialWarningSpell(72295, "Ranged", nil, nil, 2, 2)

local timerChokingGasBombCD			= mod:NewCDTimer(35, 71255, nil, nil, nil, 3, nil, nil, true) -- ~5s variance [35.1-39.8]. Added "keep" arg (*bad phasing - Bennu: 25N [2023-06-09]@[21:21:35]* || 25H [2023-07-20]@[21:54:29]* || 25H [2023-07-27]@[21:54:34]*) - "Bomba de gas asfixiante-71255-npc:36678-1277231 = pull:55.7/Stage 2/4.1, 38.4, 35.7, 38.5, Stage 2.5/35.7, Stage 3/19.5, 8.2/27.7/63.4, 35.1 || pull:114.9/Stage 2/8.5, 37.6, Stage 2.5/31.4, Stage 3/46.2, 6.4/52.6/84.0 || pull:100.5/Stage 1.5/44.1, Stage 2/8.1, 27.4/35.6, 37.1, 38.7, Stage 2.5/17.8, Stage 3/44.8, 25.9/70.6/88.4"
local timerChokingGasBombExplosion	= mod:NewCastTimer(12, 71279, nil, nil, nil, 2)
local timerMalleableGooCD			= mod:NewNextTimer(20, 72295, nil, nil, nil, 3) -- Fixed timer (*bad phasing - Bennu: 25H [2023-07-27]@[21:54:34]*) - "?-|TInterface\\Icons\\inv_misc_herb_evergreenmoss.blp:16|t ¡%s lanza |cFF00FF00Moco maleable!|r-npc:Profesor Putricidio = pull:107.4/Stage 1.5/51.0, Stage 2/1.2, 18.8/20.0, 20.0, 20.0, 20.0, 20.0, 20.0, Stage 2.5/2.1, Stage 3/44.8, 22.1/66.9/69.0, 20.0"

local soundSpecWarnMalleableGoo		= mod:NewSound(72295, nil, "Ranged")
local soundMalleableGooSoon			= mod:NewSoundSoon(72295, nil, "Ranged")
local soundSpecWarnChokingGasBomb	= mod:NewSound(71255, nil, "Melee")
local soundChokingGasSoon			= mod:NewSoundSoon(71255, nil, "Melee")

--mod:AddSetIconOption("MalleableGooIcon", 72295, true, 0, {1})
--mod:AddArrowOption("GooArrow", 72295)

-- Stage Three
mod:AddTimerLine(DBM_CORE_L.SCENARIO_STAGE:format(3)..": 35% – 0%")
local warnPhase3					= mod:NewPhaseAnnounce(3, 2, nil, nil, nil, nil, nil, 2)
local warnMutatedPlague				= mod:NewStackAnnounce(72451, 3, nil, "Tank|Healer|RemoveEnrage") -- Phase 3 ability

local timerMutatedPlagueCD			= mod:NewCDTimer(10, 72451, nil, "Tank|Healer|RemoveEnrage", nil, 5, nil, DBM_COMMON_L.TANK_ICON)				-- 10 to 11

-- Intermission
mod:AddTimerLine(DBM_COMMON_L.INTERMISSION)
local warnPhase2Soon				= mod:NewPrePhaseAnnounce(2)
local warnPhase3Soon				= mod:NewPrePhaseAnnounce(3)
local warnTearGas					= mod:NewSpellAnnounce(71617, 2)		-- Phase transition normal
local warnVolatileExperiment		= mod:NewSpellAnnounce(72843, 4)		-- Phase transition heroic
local warnReengage					= mod:NewAnnounce("WarnReengage", 6, 1180)

local specWarnOozeVariable			= mod:NewSpecialWarningYou(70352, nil, nil, nil, nil, nil, 3)	-- Heroic Ability
local specWarnGasVariable			= mod:NewSpecialWarningYou(70353, nil, nil, nil, nil, nil, 3)	-- Heroic Ability

local timerNextPhase				= mod:NewPhaseTimer(30)
local timerReengage					= mod:NewTimer(20, "TimerReengage", 1180, nil, nil, 6)
--local timerTearGas					= mod:NewBuffFadesTimer(16, 71617, nil, nil, nil, 6)
--local timerPotions					= mod:NewBuffActiveTimer(30, 71621, nil, nil, nil, 6)

mod:GroupSpells(71255, 71279) -- Choking Gas Bomb, Choking Gas Explosion

local redOozeGUIDsCasts = {}
local PuddleTime = 0
local UnboundTime = 0
mod.vb.warned_preP2 = false
mod.vb.warned_preP3 = false
--mod.vb.slimePuddleCount = 0

--[[local difficultyName = "all"
local allTimers = {
	["all"] = {
		[1] = {
			["slimepuddle"] = {10.0, 33.8}, -- ~5s variance [33.8-38.4] (Bennu: 10H [2023-07-19]@[23:09:11] || 25H [2023-07-20]@[21:54:29] || 25H [2023-07-27]@[21:54:34] || 25H [2023-10-26]@[21:58:17]) - [calculated] pull:10.4, 38.4 || pull:12.0, 33.8 || pull:10.4, 37.8 || pull:10.44/Stage 1/10.44, 0.06, 36.53, 0.88
		},
		[1.5] = {
			["slimepuddle"] = {44.6}, -- (25H || 25H || 25H) - [calculated] Stage 1.5/7.5, 45.8 || Stage 1.5/7.9, 44.6 || Stage 1.5/7.90, Intermission 1/17.48
		},
		[2] = {
			["slimepuddle"] = {27.5}, -- (25H || 25H || 25H) - [calculated] Stage 2/4.0, 27.9, 36.9 || Stage 2/5.3, 27.5, 38.7, 33.2 || Stage 2/11.80, 15.74/27.54/45.03/52.93, 1.47, 34.63, 1.48, 33.97, 0.41, 36.28, 0.26
		},
--		[2.5] = {
--			["slimepuddle"] = {14.0, 22.5, 26.4, 30.5, 30.5, 22.5, 34.4}, -- (25H || 25H || 25H) - no summons [calculated] Stage 2.5/12.6 || Stage 2.5/20.4 || Stage 2.5/12.05, Intermission 2/17.63
--		},
		[3] = {
			["slimepuddle"] = {2.3, 19.9, 19.8}, -- (25H || 25H || 25H) - [calculated] Stage 3/46.2, 2.4, 20.1 || Stage 3/44.8, 2.3, 19.9, 19.8 || Stage 3/14.83, 15.89/30.72/48.35/60.40, 1.02, 18.82, 0.07
		},
	},
}]]

local function NextPhase(self)
	self:SetStage(self.vb.phase + 0.5)
	if self.vb.phase == 2 then
		warnPhase2:Show()
		warnPhase2:Play("ptwo")
		self:UnregisterShortTermEvents() -- UnregisterShortTermEvents moved here to ensure UNIT_TARGET is unregistered (previously was running on sync, which is not always used)
	elseif self.vb.phase == 3 then
		warnPhase3:Show()
		warnPhase3:Play("pthree")
		self:UnregisterShortTermEvents() -- UnregisterShortTermEvents moved here to ensure UNIT_TARGET is unregistered (previously was running on sync, which is not always used)
	end
end

-- This does not work on Warmane - boss never swaps targets to throw malleable (last checked on 14/07/2021)
--[[function mod:MalleableGooTarget(targetname, uId)
	if not targetname then return end
		if self.Options.MalleableGooIcon then
			self:SetIcon(targetname, 1, 10)
		end
	if targetname == UnitName("player") then
		specWarnMalleableGoo:Show()
		specWarnMalleableGoo:Play("targetyou")
		yellMalleableGoo:Yell()
		soundSpecWarnMalleableGoo:Play("Interface\\AddOns\\DBM-Core\\sounds\\RaidAbilities\\malleable.mp3")
	else
		if self:CheckNearby(11, targetname) then
			specWarnMalleableGooNear:Show(targetname)
			specWarnMalleableGooNear:Play("watchstep")
			soundSpecWarnMalleableGoo:Play("Interface\\AddOns\\DBM-Core\\sounds\\RaidAbilities\\malleable.mp3")
		else
			specWarnMalleableGooCast:Show()
			specWarnMalleableGooCast:Play("watchstep")
			soundSpecWarnMalleableGoo:Play("Interface\\AddOns\\DBM-Core\\sounds\\RaidAbilities\\malleable.mp3")
		end
		if self.Options.GooArrow then
			local x, y = GetPlayerMapPosition(uId)
			if x == 0 and y == 0 then
				SetMapToCurrentZone()
				x, y = GetPlayerMapPosition(uId)
			end
			DBM.Arrow:ShowRunAway(x, y, 10, 5)
		end
	end
end]]

function mod:OnCombatStart(delay)
	self:SetStage(1)
	berserkTimer:Start(-delay)
	timerSlimePuddleCD:Start(10.2-delay) -- ~2s variance [10.2-12]. (10N Bennu [2023-06-09]@[16:21:59] || 25H Bennu [2023-07-20]@[21:54:29] || 25H Bennu [2023-07-27]@[21:54:34]) - pull:10.2 || pull:12.0 || pull:10.4
	timerUnstableExperimentCD:Start(30-delay) -- REVIEW! need P1 N log data to determine whether H/N has difference. heroic ~5s variance [30.6-33.5] (Bennu: 25H [2023-06-15]@[21:57:26] || 25H [2023-07-20]@[21:54:29] || 25H [2023-07-27]@[21:54:34]) - pull:30.6 || pull:31.2 || pull:32.3
	warnUnstableExperimentSoon:Schedule(25-delay)
	table.wipe(redOozeGUIDsCasts)
	PuddleTime = 0
	UnboundTime = 0
	self.vb.warned_preP2 = false
	self.vb.warned_preP3 = false
	if self:IsHeroic() then
		timerUnboundPlagueCD:Start(20-delay)
	end
end

function mod:OnCombatEnd()
	self:UnregisterShortTermEvents()
end

function mod:SPELL_CAST_START(args)
	local spellId = args.spellId
	if args:IsSpellID(70351, 71966, 71967, 71968) then	-- Unstable Experiment
		warnUnstableExperimentSoon:Cancel()
		warnUnstableExperiment:Show()
		timerUnstableExperimentCD:Start()
		warnUnstableExperimentSoon:Schedule(30)
	elseif spellId == 71617 then				--Tear Gas (stun all on Normal phase) (Normal intermission)
		-- (25N Bennu [2023-06-23]) - 17.20
		self:SetStage(self.vb.phase + 0.5) -- ACTION_CHANGE_PHASE
		warnTearGas:Show()
		if self.vb.phase == 2.5 then
			-- Usual timer delta is not reliable for Malleable Goo, it's a different logic, commented below
			local gooElapsed = timerMalleableGooCD:GetTime() -- On second intermission, the next Malleable Goo will always be 44s after the previous Malleable Goo cast, so calculate elapsed time and update timer
			timerMalleableGooCD:Update(gooElapsed, 44)
			soundMalleableGooSoon:Schedule(44-gooElapsed-3, "Interface\\AddOns\\DBM-Core\\sounds\\RaidAbilities\\malleable_soon.mp3")
			-- Choking Gas firing during intermission was not reliable at all since they can happen with some high variance. Noticed a ~5s variance from SCS to SCS.
			local chokingElapsed = timerChokingGasBombCD:GetTime() -- On second intermission, the next Choking Gas will be [59.98-63.4]s after the previous Choking Gas cast, so calculate elapsed time and update timer
			timerChokingGasBombCD:Update(chokingElapsed, 59.98) -- REVIEW! Represent as timestamp of the last previous phase emote > Phasing (...) > first current phase emote [diff1/diff2/diff3/diff4 with previous cast] (Bennu: 25N [2023-08-08]@[21:24:48] || 25N [2023-08-19]@[22:02:34]) - 226.68 >...> 288.21 [16.65/31.42/35.84/61.53] || 224.49 >...> 284.47 [19.85/34.63/39.28/59.98]
			soundChokingGasSoon:Schedule(59.98-chokingElapsed-3, "Interface\\AddOns\\DBM-Core\\sounds\\RaidAbilities\\choking_soon.mp3")
			warnChokingGasBombSoon:Schedule(59.98-chokingElapsed-5)
		end
	elseif args:IsSpellID(72842, 72843) then		--Volatile Experiment (Heroic intermission)
		DBM:AddMsg("Volatile Experiment SPELL_CAST_START script fixed. Notify Zidras on Discord or GitHub") -- REVIEW! Looks like it does not fire on UltimoWow
		-- TO DO: check whether delaying all running timers by 30s is accurate, according to TC. According to AC is 24+25s
		self:SetStage(self.vb.phase + 0.5) -- ACTION_CHANGE_PHASE
		warnVolatileExperiment:Show()
		warnUnstableExperimentSoon:Cancel()
		warnChokingGasBombSoon:Cancel()
		timerUnstableExperimentCD:Cancel()
--		timerSlimePuddleCD:Cancel()
		timerSlimePuddleCD:AddTime(21.83)
		timerUnboundPlagueCD:Cancel()
		if self.vb.phase == 2.5 then
			-- Usual timer delta is not reliable for Malleable Goo, it's a different logic, commented below
			local gooElapsed = timerMalleableGooCD:GetTime() -- On second intermission, the next Malleable Goo will always be 69s after the previous Malleable Goo cast, so calculate elapsed time and update timer
			timerMalleableGooCD:Update(gooElapsed, 69)
			soundMalleableGooSoon:Schedule(69-gooElapsed-3, "Interface\\AddOns\\DBM-Core\\sounds\\RaidAbilities\\malleable_soon.mp3")
			-- Choking Gas firing during intermission was not reliable at all since they can happen with some high variance. Noticed a ~5s variance from SCS to SCS.
			local chokingElapsed = timerChokingGasBombCD:GetTime() -- On second intermission, the next Choking Gas will be [84.04-88.7]s after the previous Choking Gas cast, so calculate elapsed time and update timer
			timerChokingGasBombCD:Update(chokingElapsed, 84.04) -- REVIEW! Represent as timestamp of the last previous phase emote > Phasing (...) > first current phase emote [diff1/diff2/diff3/diff4 with previous cast] (Bennu: 25H [2023-07-20]@[21:54:29] || 25H [2023-07-27]@[21:54:34] || 25N [2023-08-08]@[21:24:48] || 25H [2023-08-17]@[22:13:23] || 25N [2023-08-19]@[22:02:34]) - 202.46 >...> 286.50 [19.63/34.40/52.60/84.04] || 274.50 >...> 362.90 [39.11/53.87/70.64/88.40] || 226.68 >...> 288.21 [16.65/31.42/35.84/61.53] || 278.76 >...> 363.83 [43.72/58.48/74.64/85.07] || 224.49 >...> 284.47 [19.85/34.63/39.28/59.98]
			soundChokingGasSoon:Schedule(84.04-chokingElapsed-3, "Interface\\AddOns\\DBM-Core\\sounds\\RaidAbilities\\choking_soon.mp3")
			warnChokingGasBombSoon:Schedule(84.04-chokingElapsed-5)
		end
	elseif args:IsSpellID(72851, 72852, 71621, 72850) then		--Create Concoction (phase2 change)
		local puddleTimeAdjust = GetTime() - PuddleTime
		DBM:Debug("During Create Concoction, PuddleTime is: "..puddleTimeAdjust, 2)
		warnUnstableExperimentSoon:Cancel()
		timerUnstableExperimentCD:Cancel()
--		timerSlimePuddleCD:Cancel()
		timerUnboundPlagueCD:Cancel()
--		timerSlimePuddleCD:Start(65-puddleTimeAdjust)
		if puddleTimeAdjust > 35 then
			timerUnstableExperimentCD:Start(90-puddleTimeAdjust)
		else
			timerUnstableExperimentCD:Start(53.8-puddleTimeAdjust) -- REVIEW! Variance? Lowest possible timer?
		end
		if self:IsHeroic() then
			local p2timer = 11.77 -- REVIEW! Might require sync for better accuracy. This calculation will be used in the logs below, called "Phasing". Timestamp of p1.5 (SAA Variable) > SCS Crear brebaje > p2 (SAR Variable/UNIT_TARGET) [diff1/diff2] (Bennu: 25H [2023-07-20]@[21:54:29] || 25H [2023-07-27]@[21:54:34] || 25H [2023-08-17]@[22:13:23]) - 105.19 > 121.36 [16.17] > 133.11 [11.75/27.92] || 119.06 > 136.21 [17.15] > 147.98 [11.77/28.92] || 120.56 > 137.41 [16.85] > 149.18 [11.77/28.62]
			timerNextPhase:Start(p2timer)
			timerMalleableGooCD:Start(32.72) -- REVIEW! On first intermission, timer delta is fixed from Concoction start? Represent as Phasing (...) > emote timestamp [diff1/diff2/diff3] (25H [2023-07-20]@[21:54:29] || 25H [2023-07-27]@[21:54:34] || 25H [2023-08-17]@[22:13:23]) - 155.50 [22.39/34.14/50.31] || 170.07 [22.09/33.86/51.01] || 173.23 [24.05/35.82/52.67]
			soundMalleableGooSoon:Schedule(32.72-3, "Interface\\AddOns\\DBM-Core\\sounds\\RaidAbilities\\malleable_soon.mp3")
			timerChokingGasBombCD:Start(26.87) -- ~18s variance [26.87-43.52]! Represent as Phasing (...) > emote timestamp [diff1/diff2/diff3] (Bennu: 25H [2023-07-20]@[21:54:29] || 25H [2023-07-27]@[21:54:34] || 25H [2023-08-17]@[22:13:23]) - 164.88 [31.77/43.52/59.69] || 163.13 [15.15/26.92/44.07] || 168.71 [19.53/31.30/48.15]
			soundChokingGasSoon:Schedule(26.87-3, "Interface\\AddOns\\DBM-Core\\sounds\\RaidAbilities\\choking_soon.mp3")
			warnChokingGasBombSoon:Schedule(26.87-5)
			timerUnboundPlagueCD:Start(109-(GetTime()-UnboundTime)) -- REVIEW! (25H Bennu [2023-07-27]@[21:54:34]) - debug 11.0/delta p2 43.57
--			if self:IsDifficulty("heroic10") then -- Apply to both 10H and 25H (reason below)
				self:Schedule(p2timer, NextPhase, self)	--When PP sets target
				self:RegisterShortTermEvents(
					"UNIT_TARGET"
				)
--			end
		else
			timerNextPhase:Start(11.77) -- This calculation will be used in the logs below, called "Phasing". Timestamp of p1.5 (SCStart Tear Gas) > SCS Crear brebaje > p2 (SAR Tear Gas) [diff1/diff2] (25N [2023-08-08]@[21:24:48] || 25N [2023-08-19]@[22:02:34] || 25N [2023-08-22]@[22:37:10]) - 122.91 > 129.18 [6.27] > 140.95 [11.77/18.04] || 84.77 > 89.56 [4.79] > 101.37 [11.81/16.60] || 47.08 > 52.66 [5.58] > 64.43 [11.77/17.35] || 117.40 > 124.27 [6.87] > 136.06 [11.79/18.66]
			timerMalleableGooCD:Start(18.73) -- REVIEW! On first intermission, timer delta has variance - ~4s [18.73-22.76]. Represent as emote timestamp [diff1/diff2/diff3] (25N [2023-08-08]@[21:24:48] || 25N [2023-08-19]@[22:02:34] || 25N [2023-08-22]@[22:37:10] || 25N [2023-08-26]@[22:25:04]) - 151.31 [10.36/22.13/28.4] || 112.32 [10.95/22.76/27.55] || 74.28 [9.8/21.62/27.20] || 143.00 [6.94/18.73/25.6]
			soundMalleableGooSoon:Schedule(18.73-3, "Interface\\AddOns\\DBM-Core\\sounds\\RaidAbilities\\malleable_soon.mp3")
			timerChokingGasBombCD:Start(16.68) -- ~5s variance [16.68-22.10]. Represent as CLEU timestamp [diff1/diff2/diff3] (25N [2023-08-08]@[21:24:48] || 25N [2023-08-19]@[22:02:34] || 25N [2023-08-22]@[22:37:10]) - 151.28 [10.33/22.10/28.37] || 108.30 [6.93/18.74/23.53] || 69.34 [4.9/16.68/22.26]
			soundChokingGasSoon:Schedule(16.68-3, "Interface\\AddOns\\DBM-Core\\sounds\\RaidAbilities\\choking_soon.mp3")
			warnChokingGasBombSoon:Schedule(16.68-5)
		end
	elseif args:IsSpellID(70672, 72455, 72832, 72833) then	--Red Slime
		timerGaseousBloatCast:Start(args.sourceGUID) -- account for multiple red oozes
		if not redOozeGUIDsCasts[args.sourceGUID] then
			redOozeGUIDsCasts[args.sourceGUID] = 1
		else
			redOozeGUIDsCasts[args.sourceGUID] = redOozeGUIDsCasts[args.sourceGUID] + 1
		end
		if redOozeGUIDsCasts[args.sourceGUID] > 1 then -- Red Ooze retarget
			specWarnGaseousBloatCast:Show()
			specWarnGaseousBloatCast:Play("targetchange")
		end
	elseif args:IsSpellID(73121, 73122, 73120, 71893) then		--Guzzle Potions (phase3 change)
		local currentTime = GetTime()
		local puddleTimeAdjust = currentTime-PuddleTime
		local unboundTimeAdjust = currentTime-UnboundTime
		local p3timer = 14.77 -- REVIEW! Might require sync for better accuracy. ~1s variance. This calculation will be used in the logs, called "Phasing". Timestamp of p2.5 > SCS Tragar pociones > p3 (SAR/UNIT_TARGET) [diff1/diff2]. (Bennu: [2023-06-03]@[20:22:52] || 10H [2023-07-19]@[23:09:11] || 25H [2023-07-20]@[21:54:29] || 25H [2023-07-27]@[21:54:34] || 25N [2023-08-08]@[21:24:48] || 25H [2023-08-17]@[22:13:23] || 25N [2023-08-19]@[22:02:34]) - 14.86 || 14.79 || 233.90 > 252.10 [18.2] > 266.87 [14.77/32.97] || 292.26 > 309.03 [16.77] > 323.79 [14.76/31.53] || 252.37 > 256.79 [4.42] > 271.56 [14.77/19.19] || 289.19 > 305.35 [16.16] > 320.11 [14.76/30.92] || 245.19 > 249.84 [4.65] > 264.62 [14.78/19.43]
		DBM:Debug(format("During Guzzle Potions, PuddleTime is %d and UnboundTime is %d", puddleTimeAdjust, unboundTimeAdjust), 2)
		timerUnstableExperimentCD:Cancel()
--		timerSlimePuddleCD:Cancel()
		timerUnboundPlagueCD:Cancel()
		timerNextPhase:Start(p3timer)
--		timerSlimePuddleCD:Start(65-puddleTimeAdjust)
		timerUnboundPlagueCD:Start(120-unboundTimeAdjust)		--this requires more analysis
		if self:IsHeroic() then -- Apply to both 10H and 25H (reason below)
			self:Schedule(p3timer, NextPhase, self)
			self:RegisterShortTermEvents(
				"UNIT_TARGET"
			)
		end
	end
end

function mod:SPELL_CAST_SUCCESS(args)
	local spellId = args.spellId
	if spellId == 70341 and self:AntiSpam(5, 1) then
		DBM:AddMsg("Slime Puddle SPELL_CAST_SUCCESS unhidden from combat log. Notify Zidras on Discord or GitHub") -- It does not fire on UltimoWow. Replaced with SPELL_SUMMON
		warnSlimePuddle:Show()
		soundSlimePuddle:Play("Interface\\AddOns\\DBM-Core\\sounds\\RaidAbilities\\puddle_cast.mp3")
		timerSlimePuddleCD:Start()
		PuddleTime = GetTime()
	elseif spellId == 71255 then -- Choking Gas
		warnChokingGasBomb:Show()
		specWarnChokingGasBomb:Show()
		soundSpecWarnChokingGasBomb:Play("Interface\\AddOns\\DBM-Core\\sounds\\RaidAbilities\\choking.mp3")
		soundChokingGasSoon:Cancel()
		soundChokingGasSoon:Schedule(35.5-3, "Interface\\AddOns\\DBM-Core\\sounds\\RaidAbilities\\choking_soon.mp3")
		timerChokingGasBombCD:Start()
		timerChokingGasBombExplosion:Start()
		warnChokingGasBombSoon:Schedule(30.5)
	elseif args:IsSpellID(72855, 72856, 70911) then
		timerUnboundPlagueCD:Start()
		UnboundTime = GetTime()
	elseif args:IsSpellID(72615, 72295, 74280, 74281) then -- Malleable Goo
		DBM:AddMsg("Malleable Goo SPELL_CAST_SUCCESS unhidden from combat log. Notify Zidras on Discord or GitHub") -- It does not fire on UltimoWow. Replaced with CHAT_MSG_RAID_BOSS_EMOTE
		--self:BossTargetScanner(36678, "MalleableGooTarget", 0.05, 6)
		specWarnMalleableGooCast:Show()
		--specWarnMalleableGooCast:Play("watchstep")
		timerMalleableGooCD:Start()
		soundSpecWarnMalleableGoo:Play("Interface\\AddOns\\DBM-Core\\sounds\\RaidAbilities\\malleable.mp3")
		soundMalleableGooSoon:Cancel()
		soundMalleableGooSoon:Schedule(20-3, "Interface\\AddOns\\DBM-Core\\sounds\\RaidAbilities\\malleable_soon.mp3")
	end
end

function mod:SPELL_AURA_APPLIED(args)
	local spellId = args.spellId
	if args:IsSpellID(70447, 72836, 72837, 72838) then--Green Slime
		if args:IsPlayer() then--Still worth warning 100s because it does still do knockback
			specWarnVolatileOozeAdhesive:Show()
		elseif not self:IsTank() then
			specWarnVolatileOozeAdhesiveT:Show(args.destName)
			specWarnVolatileOozeAdhesiveT:Play("helpsoak")
		else
			warnVolatileOozeAdhesive:Show(args.destName)
		end
		if self.Options.OozeAdhesiveIcon then
			self:SetIcon(args.destName, 1)
		end
	elseif args:IsSpellID(70672, 72455, 72832, 72833) then	--Red Slime
		timerGaseousBloat:Start(args.destName)
		if args:IsPlayer() then
			specWarnGaseousBloat:Show()
			specWarnGaseousBloat:Play("justrun")
			specWarnGaseousBloat:ScheduleVoice(1.5, "keepmove")
		else
			warnGaseousBloat:Show(args.destName)
		end
		if self.Options.GaseousBloatIcon then
			self:SetIcon(args.destName, 2)
		end
	--elseif args:IsSpellID(71615, 71618) then	--71615 used in 10 and 25 normal, 71618?
	--	timerTearGas:Start()
	elseif args:IsSpellID(72451, 72463, 72671, 72672) then	-- Mutated Plague
		warnMutatedPlague:Show(args.destName, args.amount or 1)
		timerMutatedPlagueCD:Start()
	elseif spellId == 70542 then
		timerMutatedSlash:Show(args.destName)
	elseif args:IsSpellID(70539, 72457, 72875, 72876) then
		timerRegurgitatedOoze:Show(args.destName)
	elseif args:IsSpellID(70352, 74118) then	--Ooze Variable
		if args:IsPlayer() then
			specWarnOozeVariable:Show()
		end
	elseif args:IsSpellID(70353, 74119) then	-- Gas Variable
		if args:IsPlayer() then
			specWarnGasVariable:Show()
		end
	elseif args:IsSpellID(72855, 72856, 70911) then	 -- Unbound Plague
		if self.Options.UnboundPlagueIcon then
			self:SetIcon(args.destName, 3)
		end
		if args:IsPlayer() then
			specWarnUnboundPlague:Show()
			specWarnUnboundPlague:Play("targetyou")
			timerUnboundPlague:Start()
			yellUnboundPlague:Yell()
		else
			warnUnboundPlague:Show(args.destName)
		end
	end
end

function mod:SPELL_AURA_APPLIED_DOSE(args)
	if args:IsSpellID(72451, 72463, 72671, 72672) then	-- Mutated Plague
		warnMutatedPlague:Show(args.destName, args.amount or 1)
		timerMutatedPlagueCD:Start()
	elseif args.spellId == 70542 then
		timerMutatedSlash:Show(args.destName)
	end
end

function mod:SPELL_AURA_REFRESH(args)
	if args:IsSpellID(70539, 72457, 72875, 72876) then
		timerRegurgitatedOoze:Show(args.destName)
	elseif args.spellId == 70542 then
		timerMutatedSlash:Show(args.destName)
	end
end

function mod:SPELL_AURA_REMOVED(args)
	local spellId = args.spellId
	if args:IsSpellID(70447, 72836, 72837, 72838) then
		if self.Options.OozeAdhesiveIcon then
			self:SetIcon(args.destName, 0)
		end
	elseif args:IsSpellID(70672, 72455, 72832, 72833) then
		timerGaseousBloat:Cancel(args.destName)
		if self.Options.GaseousBloatIcon then
			self:SetIcon(args.destName, 0)
		end
	elseif args:IsSpellID(72855, 72856, 70911) then						-- Unbound Plague
		timerUnboundPlague:Stop(args.destName)
		if self.Options.UnboundPlagueIcon then
			self:SetIcon(args.destName, 0)
		end
	elseif spellId == 71615 and (self.vb.phase == 1.5 or self.vb.phase == 2.5) then	-- Tear Gas Removal. Requires phase check because sometimes Tear Gas is removed from Abomination much later than the rest of the raid, during phase 2, causing another phasing to 2.5 (Logs: 10N Frostmourne [2023-01-07]@[17:20:22] and [2023-01-07]@[17:42:33] || 10N Icecrown [2023-04-05]@[22:54:25])
		NextPhase(self)
	elseif args:IsSpellID(70539, 72457, 72875, 72876) then
		timerRegurgitatedOoze:Cancel(args.destName)
	elseif spellId == 70542 then
		timerMutatedSlash:Cancel(args.destName)
	elseif (args:IsSpellID(70352, 74118) or args:IsSpellID(70353, 74119)) and (self.vb.phase == 1.5 or self.vb.phase == 2.5) then	-- Ooze Variable / Gas Variable (Heroic 25 - Phase 2 and 3). Disabled for one main reason: raid member dying will trigger this event
		DBM:Debug("Variable phasing time marker")
--		NextPhase(self)
	end
end

function mod:SPELL_SUMMON(args)
	local spellId = args.spellId
	if spellId == 70342 and self:AntiSpam(5, 1) then
--		local timer = self:GetFromTimersTable(allTimers, "all", self.vb.phase, "slimepuddle", self.vb.slimePuddleCount+1) or 33.2
		warnSlimePuddle:Show()
		soundSlimePuddle:Play("Interface\\AddOns\\DBM-Core\\sounds\\RaidAbilities\\puddle_cast.mp3")
		if self.vb.phase == 3 then
			timerSlimePuddleCD:Start(19.8)
		else
			timerSlimePuddleCD:Start()
		end
		PuddleTime = GetTime()
	end
end

function mod:CHAT_MSG_MONSTER_YELL(msg)
	if msg == L.HeroicIntermission or msg:find(L.HeroicIntermission) then -- ACTION_CHANGE_PHASE. Workaround to UltimoWow not firing Volatile Experiment.
		self:SetStage(self.vb.phase + 0.5)
		warnUnstableExperimentSoon:Cancel()
		warnChokingGasBombSoon:Cancel()
		timerUnstableExperimentCD:Cancel()
--		timerSlimePuddleCD:Cancel()
		timerSlimePuddleCD:AddTime(21.83) -- REVIEW! According to TC, ACTION_CHANGE_PHASE delays events by 30s, but in UltimoWow it is shorter. To be confirmed whether this logic applies and if it is different between phases
		timerUnboundPlagueCD:Cancel()
		if self.vb.phase == 2.5 then
			 -- Usual timer delta is not reliable for Malleable Goo, it's a different logic, commented below
			local gooElapsed = timerMalleableGooCD:GetTime() -- On second intermission, the next Malleable Goo will always be 69s after the previous Malleable Goo cast, so calculate elapsed time and update timer
			timerMalleableGooCD:Update(gooElapsed, 69)
			soundMalleableGooSoon:Schedule(69-gooElapsed-3, "Interface\\AddOns\\DBM-Core\\sounds\\RaidAbilities\\malleable_soon.mp3")
			-- Choking Gas firing during intermission was not reliable at all since they can happen with some high variance. Noticed a ~5s variance from SCS to SCS.
			local chokingElapsed = timerChokingGasBombCD:GetTime() -- On second intermission, the next Choking Gas will be [84.04-88.7]s after the previous Choking Gas cast, so calculate elapsed time and update timer
			timerChokingGasBombCD:Update(chokingElapsed, 84.04) -- REVIEW! Represent as timestamp of the last previous phase emote > Phasing (...) > first current phase emote [diff1/diff2/diff3/diff4 with previous cast] (Bennu: 25H [2023-07-20]@[21:54:29] || 25H [2023-07-27]@[21:54:34] || 25N [2023-08-08]@[21:24:48] || 25H [2023-08-17]@[22:13:23] || 25N [2023-08-19]@[22:02:34]) - 202.46 >...> 286.50 [19.63/34.40/52.60/84.04] || 274.50 >...> 362.90 [39.11/53.87/70.64/88.40] || 226.68 >...> 288.21 [16.65/31.42/35.84/61.53] || 278.76 >...> 363.83 [43.72/58.48/74.64/85.07] || 224.49 >...> 284.47 [19.85/34.63/39.28/59.98]
			soundChokingGasSoon:Schedule(84.04-chokingElapsed-3, "Interface\\AddOns\\DBM-Core\\sounds\\RaidAbilities\\choking_soon.mp3")
			warnChokingGasBombSoon:Schedule(84.04-chokingElapsed-5)
		end
	elseif msg == L.YellTransform1 or msg:find(L.YellTransform1) then
			warnReengage:Schedule(5.5, L.name)
			timerReengage:Start(5.5)
	elseif msg == L.YellTransform2 or msg:find(L.YellTransform2) then
			warnReengage:Schedule(8.5, L.name)
			timerReengage:Start(8.5)
	end
end

function mod:CHAT_MSG_RAID_BOSS_EMOTE(msg)
	if msg:find(L.MalleableGooCastEmote) then -- Malleable Goo. Workaround to missing CLEU event
		--self:BossTargetScanner(36678, "MalleableGooTarget", 0.05, 6)
		specWarnMalleableGooCast:Show()
		--specWarnMalleableGooCast:Play("watchstep")
		timerMalleableGooCD:Start()
		soundSpecWarnMalleableGoo:Play("Interface\\AddOns\\DBM-Core\\sounds\\RaidAbilities\\malleable.mp3")
		soundMalleableGooSoon:Cancel()
		soundMalleableGooSoon:Schedule(20-3, "Interface\\AddOns\\DBM-Core\\sounds\\RaidAbilities\\malleable_soon.mp3")
	end
end

--values subject to tuning depending on dps and his health pool
function mod:UNIT_HEALTH(uId)
	if self.vb.phase == 1 and not self.vb.warned_preP2 and self:GetUnitCreatureId(uId) == 36678 and UnitHealth(uId) / UnitHealthMax(uId) <= 0.83 then
		self.vb.warned_preP2 = true
		warnPhase2Soon:Show()
		warnPhase2Soon:Play("nextphasesoon")
	elseif self.vb.phase == 2 and not self.vb.warned_preP3 and self:GetUnitCreatureId(uId) == 36678 and UnitHealth(uId) / UnitHealthMax(uId) <= 0.38 then
		self.vb.warned_preP3 = true
		warnPhase3Soon:Show()
		warnPhase3Soon:Play("nextphasesoon")
	elseif self:GetUnitCreatureId(uId) == 36678 and UnitHealth(uId) / UnitHealthMax(uId) == 0.35 then
		warnUnstableExperimentSoon:Cancel()
		warnChokingGasBombSoon:Cancel()
		soundMalleableGooSoon:Cancel()
		soundChokingGasSoon:Cancel()
	end
end

-- On 10 Heroic, there is no event we can use to accurately trigger phasing. On 25 Heroic, we could use SPELL_AURA_REMOVED, but not reliable without UnitBuff checks or table management which would add unnecessary overhead (see above)
-- UNIT_TARGET only fires if boss is targeted or focused (sync'ed below)
function mod:UNIT_TARGET(uId)
	if self:GetUnitCreatureId(uId) ~= 36678 then return end
	-- Attempt to catch when boss phases by checking for Putricide's target being a raid member
	if UnitExists(uId.."target") then
		if self.vb.phase == 1.5 then
			self:SendSync("ProfessorPhase2") -- Sync phasing with raid since UNIT_TARGET event requires boss to be target/focus, which not all members do
		elseif self.vb.phase == 2.5 then
			self:SendSync("ProfessorPhase3") -- Sync phasing with raid since UNIT_TARGET event requires boss to be target/focus, which not all members do
		else
			self:UnregisterShortTermEvents()
			DBM:Debug("UNIT_TARGET phasing did not work since phase was wrongly set: " .. self.vb.phase)
		end
	end
end

function mod:OnSync(msg)
	if not self:IsInCombat() then return end
	if msg == "ProfessorPhase2" and self.vb.phase == 1.5 then
		self:Unschedule(NextPhase)
		NextPhase(self)
		DBM:Debug("Putricide phase 2 via UNIT_TARGET sync")
	elseif msg == "ProfessorPhase3" and self.vb.phase == 2.5 then
		self:Unschedule(NextPhase)
		NextPhase(self)
		DBM:Debug("Putricide phase 3 via UNIT_TARGET sync")
	end
end
