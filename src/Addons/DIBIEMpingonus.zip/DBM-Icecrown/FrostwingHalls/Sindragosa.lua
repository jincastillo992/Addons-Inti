local mod	= DBM:NewMod("Sindragosa", "DBM-Icecrown", 4)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20241204093130")
mod:SetCreatureID(36853)
mod:SetUsedIcons(1, 2, 3, 4, 5, 6)
mod:SetHotfixNoticeRev(20241203000000)
mod:SetMinSyncRevision(20241203000000)

mod:RegisterCombat("combat")

mod:RegisterEventsInCombat(
	"SPELL_CAST_START 69649 71056 71057 71058 73061 73062 73063 73064 71077",
	"SPELL_CAST_SUCCESS 70117 69762",
	"SPELL_AURA_APPLIED 70126 69762 70106 69766 70127 72528 72529 72530",
	"SPELL_AURA_APPLIED_DOSE 70106 69766 70127 72528 72529 72530",
	"SPELL_AURA_REMOVED 69762 70157 70106 69766 70127 72528 72529 72530",
	"UNIT_HEALTH",
	"CHAT_MSG_MONSTER_YELL"
)

local strupper = strupper

-- General
local berserkTimer				= mod:NewBerserkTimer(600)

mod:AddBoolOption("RangeFrame", true) -- keep as BoolOption since the localization offers important information regarding boss ability and player debuff behaviour (Unchained Magic is Heroic only)
mod:AddBoolOption("ClearIconsOnAirphase", true) -- don't group with any spellId, it applies to all raid icons

-- Stage One
mod:AddTimerLine(DBM_CORE_L.SCENARIO_STAGE:format(1))
local warnAirphase				= mod:NewAnnounce("WarnAirphase", 2, 43810)
local warnGroundphaseSoon		= mod:NewAnnounce("WarnGroundphaseSoon", 2, 43810)
local warnPhase2soon			= mod:NewPrePhaseAnnounce(2)
local warnInstability			= mod:NewCountAnnounce(69766, 2, nil, false)
local warnChilledtotheBone		= mod:NewCountAnnounce(70106, 2, nil, false)
local warnFrostBeacon			= mod:NewTargetNoFilterAnnounce(70126, 4)
local warnFrostBreath			= mod:NewSpellAnnounce(69649, 2, nil, "Tank|Healer")
local warnUnchainedMagic		= mod:NewTargetAnnounce(69762, 2, nil, "SpellCaster", 2)

local specWarnUnchainedMagic	= mod:NewSpecialWarningYou(69762, nil, nil, nil, 1, 2)
local specWarnFrostBeacon		= mod:NewSpecialWarningMoveAway(70126, nil, nil, nil, 3, 2)
local specWarnFrostBeaconSide	= mod:NewSpecialWarningMoveTo(70126, nil, nil, nil, 3, 2)
local specWarnInstability		= mod:NewSpecialWarningStack(69766, nil, mod:IsHeroic() and 4 or 8, nil, nil, 1, 6)
local specWarnChilledtotheBone	= mod:NewSpecialWarningStack(70106, nil, mod:IsHeroic() and 4 or 8, nil, nil, 1, 6)
local specWarnBlisteringCold	= mod:NewSpecialWarningRun(70123, nil, nil, nil, 4, 2)

local timerNextAirphase			= mod:NewTimer(64.8, "TimerNextAirphase", 43810, nil, nil, 6) -- (10H Bennu [2023-07-08]@[23:19:27], multiple) - all 64.8
local timerNextGroundphase		= mod:NewTimer(45.9, "TimerNextGroundphase", 43810, nil, nil, 6) -- ~0.1s  variance [45.90-46.04]. Timestamps consists of YELL > UNIT_TARGET [diff] (Bennu: 25H [2023-07-20]@[22:39:09] || 25H [2023-10-26]@[23:01:27]) - 76.41 > 122.45 [46.04], 186.41 > 232.44 [46.03] || 61.43 > 107.33 [45.9]
local timerNextFrostBreath		= mod:NewCDTimer(20.1, 69649, nil, "Tank|Healer", nil, 5, nil, DBM_COMMON_L.TANK_ICON) -- REVIEW! ~3s variance [P1:21.9-23.3;P2:20.1-23.1] (10H Bennu [2023-07-08]@[23:48:34]) "Aliento de Escarcha-71057-npc:36853-3766823 = pull:10.2/Stage 1/10.2, 23.3, Stage 1.5/16.5, Stage 1/45.2, 6.2/51.4/67.9, 22.2, 21.9, Stage 1.5/14.6, Stage 1/45.2, 7.7/52.9/67.5, Stage 2/9.2""Aliento de Escarcha-73063-npc:36853-3766823 = pull:235.7/Stage 2/13.7, 20.1, 23.8, 21.1, 23.1",
local timerNextBlisteringCold	= mod:NewCDTimer(68.2, 70123, nil, nil, nil, 2, nil, DBM_COMMON_L.DEADLY_ICON, true, 2) -- based on Icy Grip (70117). ~8s variance [68.1-77.63]. Added "keep" arg. (Bennu: 25N [2023-06-03]@[20:22:52] || 25H [2023-06-08]@[21:15:19] || 10N [2023-06-09]@[16:21:59] || 25H [2023-06-29]@[23:19:27] || 10H [2023-07-08]@[23:48:34] || 25H [2023-10-26]@[23:01:27]) - "Agarre helado-70117-npc:36853-1728778 = pull:33.5/Stage 1/33.0, Stage 1.5/16.5, Stage 1/45.2, 37.0/82.2/98.7, Stage 2/28.6, 36.8/65.4 || "Agarre helado-70117-npc:36853-1434878 = pull:33.4/Stage 1/32.9, Stage 1.5/16.5, Stage 1/45.2, 37.7/82.9/99.4, Stage 1.5/27.4, Stage 1/45.2, 40.2/85.4/112.8, Stage 2/7.8, 36.6/44.4, 76.7 || "Agarre helado-70117-npc:36853-868144 = pull:33.5/Stage 1/33.0, Stage 1.5/16.5, Stage 1/45.2, 40.5/85.7/102.1, Stage 1.5/24.3, Stage 1/45.2, Stage 2/18.8, 39.6/58.3/103.6/127.9, 68.2 || "Agarre helado-70117-npc:36853-3725047 = pull:33.5/Stage 1/33.5, Stage 1.5/16.5, Stage 1/45.2, 36.6/81.8/98.3, Stage 1.5/28.2, Stage 1/45.2, Stage 2/34.5, 35.2/69.7/114.9/143.1, 68.9 || "Agarre helado-70117-npc:36853-3766823 = pull:35.0/Stage 1/35.0, Stage 1.5/15.0, Stage 1/45.2, 36.9/82.1/97.1, Stage 1.5/27.9, Stage 1/45.2, Stage 2/16.8, 37.0/53.8/99.0/126.9, 68.1 || "Agarre helado-70117-npc:36853-4091162 = pull:34.58/Stage 1/34.58, Stage 1.5/15.43, Stage 1/45.01, 33.25/78.26/93.69, Stage 1.5/31.72, Stage 1/45.01, Stage 2/24.40, 46.75/71.15/116.16/147.88, 77.63"
local timerNextBeacon			= mod:NewNextCountTimer(15, 70126, nil, nil, nil, 3, nil, DBM_COMMON_L.DEADLY_ICON) -- ~7s variance [15.0-22.1] (Bennu: 25N [2023-06-03]@[20:22:52] || 25H [2023-06-08]@[21:15:19] || 10N [2023-06-09]@[16:21:59] || 25H [2023-06-29]@[23:19:27] || 10H [2023-07-08]@[23:48:34] || 25H [2023-10-26]@[23:01:27]) - "Señal de Escarcha-70126-npc:36853-1728778 = pull:57.2/Stage 1.5/7.3[+4], Stage 1/37.9, Stage 2/65.7, 8.1/73.8/111.7, 15.2, 20.5, 15.6 || "Señal de Escarcha-70126-npc:36853-1434878 = pull:57.4/Stage 1.5/7.4[+5], Stage 1/37.8, Stage 1.5/65.1, 6.8/71.9/109.7[+5], Stage 1/38.4, Stage 2/48.1, 7.9/56.0/94.3, 15.4, 20.3, 15.8, 15.2, 15.5, 15.2, 15.2, 15.4 || "Señal de Escarcha-70126-npc:36853-868144 = pull:57.6/Stage 1.5/7.6[+1], Stage 1/37.6, Stage 1.5/64.8, 7.6/72.4/110.0[+1], Stage 1/37.6, Stage 2/18.8, 9.5/28.3/65.9, 15.2, 21.9, 15.1, 15.6, 16.4, 21.1, 15.0, 15.5, 15.1 || "Señal de Escarcha-70126-npc:36853-3725047 = pull:57.2/Stage 1.5/7.2[+5], Stage 1/38.0, Stage 1.5/64.8, 7.3/72.1/110.1[+5], Stage 1/37.9, Stage 2/34.5, 9.2/43.6/81.5, 16.0, 18.4, 15.1, 15.1, 15.8, 22.1 || "Señal de Escarcha-70126-npc:36853-3766823 = pull:57.4/Stage 1.5/7.4[+1], Stage 1/37.8, Stage 1.5/64.8, 7.7/72.5/110.3[+1], Stage 1/37.5, Stage 2/16.8, 9.7/26.6/64.0, 15.2, 19.0, 16.0, 16.5, 15.6
local timerBeaconIncoming		= mod:NewTargetTimer("d7", 70126, nil, nil, nil, 3) -- One incoming timer for each target
local timerBlisteringCold		= mod:NewCastTimer(6, 70123, nil, nil, nil, 2)
local timerUnchainedMagic		= mod:NewCDTimer(30.1, 69762, nil, nil, nil, 3, nil, nil, true) -- ~5s variance [30.1-34.8]. Added "keep" arg. (25N Bennu [2023-06-03]@[20:22:52] || 25H Bennu [2023-06-08]@[21:15:19] || 10N Bennu [2023-06-09]@[16:21:59] || 25H Bennu [2023-06-29]@[23:19:27] || 10H Bennu [2023-07-08]@[23:48:34]) - "Magia desencadenada-69762-npc:36853-1728778 = pull:10.3/Stage 1/9.8, 33.1, Stage 1.5/6.6, Stage 1/45.2, 12.9/58.1/64.7, 31.4, Stage 2/21.4, 10.5/31.9, 32.3 || "Magia desencadenada-69762-npc:36853-1434878 = pull:12.9/Stage 1/12.4, 31.4, Stage 1.5/5.6, Stage 1/45.2, 13.9/59.1/64.7, 33.4, Stage 1.5/17.8, Stage 1/45.2, 15.2/60.4/78.2, Stage 2/32.9, 1.2/34.1, 34.5, 32.8, 32.1, 34.8 || "Magia desencadenada-69762-npc:36853-868144 = pull:11.9/Stage 1/11.4, 32.4, Stage 1.5/5.7, Stage 1/45.2, 14.3/59.5/65.1, 32.9, Stage 1.5/17.6, Stage 1/45.2, 15.3/60.5/78.1, Stage 2/3.5, 29.0/32.5, 30.2, 32.3, 34.1, 32.8 || "Magia desencadenada-69762-npc:36853-3725047 = pull:11.7/Stage 1/11.7, 32.8, Stage 1.5/5.5, Stage 1/45.2, 13.9/59.1/64.5, 30.1, Stage 1.5/20.8, Stage 1/45.2, 16.5/61.7/82.5, Stage 2/17.9, 14.3/32.3, 34.8, 33.3, 33.3 || "Magia desencadenada-69762-npc:36853-3766823 = pull:12.0/Stage 1/12.0, 34.7, Stage 1.5/3.3, Stage 1/45.2, 12.2/57.4/60.7, 31.3, Stage 1.5/21.3, Stage 1/45.2, 13.1/58.3/79.6, Stage 2/3.7, 29.8/33.5, 33.6, 32.5
local timerInstability			= mod:NewBuffFadesTimer(5, 69766, nil, nil, nil, 5)
local timerChilledtotheBone		= mod:NewBuffFadesTimer(8, 70106, nil, nil, nil, 5)
local timerTailSmash			= mod:NewCDTimer(22.2, 71077, nil, nil, nil, 2, nil, nil, true) -- ~5s variance [22.2-26.9]? Added "keep" arg. (Bennu: 25N [2023-06-03]@[20:22:52] || 25H [2023-06-08]@[21:15:19] || 10N [2023-06-09]@[16:21:59] || 25H [2023-06-29]@[23:19:27] || 10H [2023-07-08]@[23:48:34] || 25H [2023-10-26]@[23:01:27]) - "Machaque de cola-71077-npc:36853-1728778 = pull:20.0/Stage 1/19.5, 22.3, Stage 1.5/7.6, Stage 1/45.2, 20.6/65.8/73.4, 22.5, Stage 2/22.6, 3.6/26.2, 26.9, 24.1 || "Machaque de cola-71077-npc:36853-1434878 = pull:20.0/Stage 1/19.5, 25.8, Stage 1.5/4.2, Stage 1/45.2, 20.5/65.7/70.0, 23.4, Stage 1.5/21.2, Stage 1/45.2, 22.6/67.8/88.9, Stage 2/25.5, 0.2/25.7, 24.6, 23.9, 26.0, 26.9, 23.3 || "Machaque de cola-71077-npc:36853-868144 = pull:20.0/Stage 1/19.5, 26.1, Stage 1.5/3.9, Stage 1/45.2, 23.5/68.7/72.6, 25.7, Stage 1.5/15.6, Stage 1/45.2, Stage 2/18.8, 2.7/21.5/66.7/82.3, 22.6, 22.9, 22.2, 22.2, 24.2, 24.0 || "Machaque de cola-71077-npc:36853-3725047 = pull:20.0/Stage 1/20.0, 26.6, Stage 1.5/3.5, Stage 1/45.2, 21.8/67.0/70.5, 23.5, Stage 1.5/19.5, Stage 1/45.2, 23.8/69.0/88.5, Stage 2/10.7, 16.1/26.7, 27.5, 23.5, 23.2, 26.4" || "Machaque de cola-71077-npc:36853-3766823 = pull:20.0/Stage 1/20.0, 24.5, Stage 1.5/5.5, Stage 1/45.2, 21.2/66.4/71.8, 23.4, Stage 1.5/20.3, Stage 1/45.2, Stage 2/16.8, 0.8/17.7/62.9/83.1, 25.8, 24.5, 24.3, 27.8" || pull:20.00/Stage 1/20.00, 23.29, Stage 1.5/6.72, Stage 1/45.01, 17.61/62.62/69.34, 22.86, 23.06, Stage 1.5/1.44, Stage 1/45.01, 17.84/62.84/64.29, Stage 2/6.57, 19.57/26.13, 25.59, 26.02, 26.76, 25.40"

local soundUnchainedMagic		= mod:NewSoundYou(69762, nil, "SpellCaster")

mod:AddSetIconOption("SetIconOnFrostBeacon", 70126, true, 7, {1, 2, 3, 4, 5, 6})
mod:AddSetIconOption("SetIconOnUnchainedMagic", 69762, true, 0, {1, 2, 3, 4, 5, 6})
mod:AddBoolOption("AnnounceFrostBeaconIcons", false, nil, nil, nil, nil, 70126)
mod:AddBoolOption("AssignWarnDirectionsCount", true, nil, nil, nil, nil, 70126)

-- Stage Two
mod:AddTimerLine(DBM_CORE_L.SCENARIO_STAGE:format(2))
local warnPhase2				= mod:NewPhaseAnnounce(2, 2, nil, nil, nil, nil, nil, 2)
local warnMysticBuffet			= mod:NewCountAnnounce(70128, 2, nil, false)

local specWarnMysticBuffet		= mod:NewSpecialWarningStack(70128, false, 5, nil, nil, 1, 6)

local timerMysticBuffet			= mod:NewBuffFadesTimer(8, 70128, nil, nil, nil, 5)
local timerNextMysticBuffet		= mod:NewNextTimer(6, 70128, nil, nil, nil, 2)
local timerMysticAchieve		= mod:NewAchievementTimer(30, 4620, "AchievementMystic")

mod:AddBoolOption("AchievementCheck", false, "announce", nil, nil, nil, 4620, "achievement")

local beaconTargets		= {}
local unchainedTargets	= {}
mod.vb.warned_P2 = false
mod.vb.warnedfailed = false
mod.vb.unchainedIcons = 1
mod.vb.beaconP2Count = 1
local playerUnchained = false
local playerBeaconed = false

local directionIndex
local DirectionAssignments = {DBM_COMMON_L.LEFT, DBM_COMMON_L.MIDDLE, DBM_COMMON_L.RIGHT}
local DirectionVoiceAssignments	= {"left", "center", "right"}

local beaconDebuffFilter, unchainedDebuffFilter
do
	local beaconDebuff, unchainedDebuff = DBM:GetSpellInfo(70126), DBM:GetSpellInfo(69762)
	beaconDebuffFilter = function(uId)
		return DBM:UnitDebuff(uId, beaconDebuff)
	end
	unchainedDebuffFilter = function(uId)
		return DBM:UnitDebuff(uId, unchainedDebuff)
	end
end

local function warnBeaconTargets(self)
	if self.Options.RangeFrame then
		if not playerBeaconed then
			DBM.RangeCheck:Show(10, beaconDebuffFilter, nil, nil, nil, 9)
		else
			DBM.RangeCheck:Show(10, nil, nil, nil, nil, 9)
		end
	end
	if self.Options.AssignWarnDirectionsCount then
		if self.vb.phase == 1.5 then
			if self:IsDifficulty("normal25") then
				-- 5 beacons
				warnFrostBeacon:Show("\n<   >"..
				strupper(DBM_COMMON_L.LEFT)		..": <".."   >"..(beaconTargets[1] or DBM_COMMON_L.UNKNOWN).."<, >"..(beaconTargets[2] or DBM_COMMON_L.UNKNOWN).."<   >\n".."<   >"..
				strupper(DBM_COMMON_L.MIDDLE)	..": <".."   >"..(beaconTargets[3] or DBM_COMMON_L.UNKNOWN).."<   >\n".."<   >"..
				strupper(DBM_COMMON_L.RIGHT)	..": <".."   >"..(beaconTargets[4] or DBM_COMMON_L.UNKNOWN).."<, >"..(beaconTargets[5] or DBM_COMMON_L.UNKNOWN))
			elseif self:IsDifficulty("heroic25") then
				-- 6 beacons
				warnFrostBeacon:Show("\n<   >"..
				strupper(DBM_COMMON_L.LEFT)		..": <".."   >"..(beaconTargets[1] or DBM_COMMON_L.UNKNOWN).."<, >"..(beaconTargets[2] or DBM_COMMON_L.UNKNOWN).."<   >\n".."<   >"..
				strupper(DBM_COMMON_L.MIDDLE)	..": <".."   >"..(beaconTargets[3] or DBM_COMMON_L.UNKNOWN).."<, >"..(beaconTargets[4] or DBM_COMMON_L.UNKNOWN).."<   >\n".."<   >"..
				strupper(DBM_COMMON_L.RIGHT)	..": <".."   >"..(beaconTargets[5] or DBM_COMMON_L.UNKNOWN).."<, >"..(beaconTargets[6] or DBM_COMMON_L.UNKNOWN))
			elseif self:IsDifficulty("normal10", "heroic10") then
				-- 2 beacons
				warnFrostBeacon:Show("\n<   >"..
				strupper(DBM_COMMON_L.LEFT)		..": <".."   >"..(beaconTargets[1] or DBM_COMMON_L.UNKNOWN).."<   >\n".."<   >"..
				strupper(DBM_COMMON_L.RIGHT)	..": <".."   >"..(beaconTargets[2] or DBM_COMMON_L.UNKNOWN))
			end
		elseif self.vb.phase == 2 then
			warnFrostBeacon:Show(beaconTargets[1].."< = >"..self.vb.beaconP2Count - 1)
		end
	else
		warnFrostBeacon:Show(table.concat(beaconTargets, "<, >"))
	end
	table.wipe(beaconTargets)
	playerBeaconed = false
end

local function warnUnchainedTargets(self)
	if self.Options.RangeFrame and self:IsHeroic() then
		if not playerUnchained then
			DBM.RangeCheck:Show(21, unchainedDebuffFilter) -- 21.5 yd with new radar calculations. 21 here since radar code adds 0.5 to activeRange
		else
			DBM.RangeCheck:Show(21) -- 21.5 yd with new radar calculations. 21 here since radar code adds 0.5 to activeRange
		end
	end
	warnUnchainedMagic:Show(table.concat(unchainedTargets, "<, >"))
	table.wipe(unchainedTargets)
	self.vb.unchainedIcons = 1
	playerUnchained = false
end

local function directionBeaconTargets(self, index)
	if index then
		if self:IsDifficulty("normal25") then
			if (index == 1 or index == 2) then directionIndex = 1		--LEFT
			elseif (index == 3) then directionIndex = 2					--CENTER
			else directionIndex = 3 end									--RIGHT
		elseif self:IsDifficulty("heroic25") then
			if (index == 1 or index == 2) then directionIndex = 1		--LEFT
			elseif (index == 3 or index == 4) then directionIndex = 2	--CENTER
			else directionIndex = 3 end									--RIGHT
		elseif self:IsDifficulty("normal10", "heroic10") then
			if index == 1 then directionIndex = 1						--LEFT
			else directionIndex = 3 end									--RIGHT
		end
		specWarnFrostBeaconSide:Show(DirectionAssignments[directionIndex])
		specWarnFrostBeaconSide:Play(DirectionVoiceAssignments[directionIndex] or "scatter")
	end
end

local function ResetRange(self)
	if self.Options.RangeFrame then
		DBM.RangeCheck:DisableBossMode()
	end
end

-- REVIEW! Timed, since there is no dedicated event for Sindragosa Landing Phase
local function landingPhaseWorkaround(self)
	-- *comment on variance if needs a -0.2 correction from schedule code previous to 11/07/2023
	-- **on 07/11/2023, schedule was changed from 45 to 46, so correction factor is -1. Applied middle ground for future log revisions
	DBM:Debug("UNIT_TARGET didn't fire. Landing Phase scheduled")
	self:SetStage(1)
	timerNextAirphase:Start()
	timerUnchainedMagic:Start(12) -- ~4s variance [12.0-16.3] (25N Bennu [2023-06-03]@[20:22:52]* || 25H Bennu [2023-06-08]@[21:15:19]* || 10N Bennu [2023-06-09]@[16:21:59]* || 25H Bennu [2023-06-29]@[23:19:27]* || 10H Bennu [2023-07-08]@[23:48:34]*) - 12.9 || 13.9, 15.2 || 14.3, 15.3 || 13.9, 16.5 || 12.2, 13.1
	timerTailSmash:Start(17) -- ~6s variance [17.59**-23.6] (25N Bennu [2023-06-03]@[20:22:52]* || 25H Bennu [2023-06-08]@[21:15:19]* || 10N Bennu [2023-06-09]@[16:21:59]* || 25H Bennu [2023-06-29]@[23:19:27]* || 10H Bennu [2023-07-08]@[23:48:34]* || 25H [2023-10-26]@[23:01:27]) - 20.6 || 20.5, 22.6 || 23.5 || 21.8, 23.8 || 21.2 || Stage 1.5/6.72, Stage 1/45.01, 17.61/62.62/69.34, 22.86, 23.06, Stage 1.5/1.44, Stage 1/45.01, 17.84/62.84/64.29
	timerNextBlisteringCold:Start(33) -- ~7s variance [33.23**-40.3] (25N Bennu [2023-06-03]@[20:22:52]* || 25H Bennu [2023-06-08]@[21:15:19]* || 10N Bennu [2023-06-09]@[16:21:59]* || 25H Bennu [2023-06-29]@[23:19:27]* || 10H Bennu [2023-07-08]@[23:48:34]*) - 37.0 || 37.7, 40.2 || 40.5 || 36.6 || 36.9 ||Stage 1.5/15.43, Stage 1/45.01, 33.25/78.26/93.69, Stage 1.5/31.72, Stage 1/45.01
--	self:UnregisterShortTermEvents()
end

local function cycleMysticBuffet(self)
--	timerNextMysticBuffet:Stop() -- disabled for debugging
	timerNextMysticBuffet:Start()
	self:Schedule(6, cycleMysticBuffet, self)
end

function mod:AnnounceBeaconIcons(uId, icon)
	if self.Options.AnnounceFrostBeaconIcons and DBM:IsInGroup() and DBM:GetRaidRank() > 1 then
		SendChatMessage(L.BeaconIconSet:format(icon, DBM:GetUnitFullName(uId)), DBM:IsInRaid() and "RAID" or "PARTY")
	end
end

function mod:OnCombatStart(delay)
	self:SetStage(1)
	berserkTimer:Start(-delay)
	timerNextAirphase:Start(50-delay)
	timerNextBlisteringCold:Start(33.4-delay) -- ~2s variance [33.4-35.0] (25N Bennu [2023-06-03]@[20:22:52] || 25H Bennu [2023-06-08]@[21:15:19] || 10N Bennu [2023-06-09]@[16:21:59] || 25H Bennu [2023-06-29]@[23:19:27] || 10H Bennu [2023-07-08]@[23:48:34]) - 33.5 || 33.4 || 33.5 || 33.5 || 35.0
	timerTailSmash:Start(20-delay) -- (25N Bennu [2023-06-03]@[20:22:52] || 25H Bennu [2023-06-08]@[21:15:19] || 10N Bennu [2023-06-09]@[16:21:59] || 25H Bennu [2023-06-29]@[23:19:27] || 10H Bennu [2023-07-08]@[23:48:34]) - 20.0 || 20.0 || 20.0 || 20.0 || 20.0
	timerUnchainedMagic:Start(10.3-delay) -- ~2s variance [10.3-12.0] (25N Bennu [2023-06-03]@[20:22:52] || 25H Bennu [2023-06-08]@[21:15:19] || 10N Bennu [2023-06-09]@[16:21:59] || 25H Bennu [2023-06-29]@[23:19:27] || 10H Bennu [2023-07-08]@[23:48:34]) - 10.3 || 12.9 || 11.9 || 11.7 || 12.0
	self.vb.warned_P2 = false
	self.vb.warnedfailed = false
	table.wipe(beaconTargets)
	table.wipe(unchainedTargets)
	self.vb.unchainedIcons = 1
	self.vb.beaconP2Count = 1
	playerUnchained = false
	playerBeaconed = false
end

function mod:OnCombatEnd()
	self:UnregisterShortTermEvents()
	if self.Options.RangeFrame then
		DBM.RangeCheck:Hide()
	end
end

function mod:SPELL_CAST_START(args)
	if args:IsSpellID(69649, 71056, 71057, 71058) or args:IsSpellID(73061, 73062, 73063, 73064) then--Frost Breath
		warnFrostBreath:Show()
		timerNextFrostBreath:Start()
	elseif args.spellId == 71077 then
		timerTailSmash:Start()
	end
end

function mod:SPELL_CAST_SUCCESS(args)
	local spellId = args.spellId
	if spellId == 70117 then--Icy Grip Cast, not blistering cold, but adds an extra 1sec to the warning
		specWarnBlisteringCold:Show()
		specWarnBlisteringCold:Play("runout")
		timerBlisteringCold:Start()
		timerNextBlisteringCold:Start()

		if self.Options.RangeFrame then
			DBM.RangeCheck:SetBossRange(25, self:GetBossUnitByCreatureId(36853))
			self:Schedule(5.5, ResetRange, self)
		end
	elseif spellId == 69762 then	-- Unchained Magic
		timerUnchainedMagic:Start()
	end
end

function mod:SPELL_AURA_APPLIED(args)
	local spellId = args.spellId
	if spellId == 70126 then
		timerBeaconIncoming:Start(args.destName)
		beaconTargets[#beaconTargets + 1] = args.destName
		if args:IsPlayer() then
			playerBeaconed = true
			-- Beacon Direction snippet
			if self.vb.phase == 1.5 and self.Options.SpecWarn70126moveto then
				for i = 1, #beaconTargets do
					local targetName = beaconTargets[i]
					if targetName == DBM:GetMyPlayerInfo() then
						directionBeaconTargets(self, i)
					end
				end
			else
				specWarnFrostBeacon:Show()
				specWarnFrostBeacon:Play("scatter")
			end
		end
		if self.vb.phase == 2 then--Phase 2 there is only one icon/beacon, don't use sorting method if we don't have to.
			self.vb.beaconP2Count = self.vb.beaconP2Count + 1
			-- several variances
			-- [(25N Bennu [2023-06-03]@[20:22:52] || 25H Bennu [2023-06-08]@[21:15:19] || 10N Bennu [2023-06-09]@[16:21:59] || 25H Bennu [2023-06-29]@[23:19:27] || 10H Bennu [2023-07-08]@[23:48:34]) - 15.2, 20.5, 15.6 || 15.4, 20.3, 15.8, 15.2, 15.5, 15.2, 15.2, 15.4 || 15.2, 21.9, 15.1, 15.6, 16.4, 21.1, 15.0, 15.5, 15.1 || 16.0, 18.4, 15.1, 15.1, 15.8, 22.1 || 15.2, 19.0, 16.0, 16.5, 15.6
			if self.vb.beaconP2Count == 3 then
				timerNextBeacon:Start(15.43, self.vb.beaconP2Count) -- 15.43-21.9
--			elseif self.vb.beaconP2Count == 7 then
--				timerNextBeacon:Start(21.1, self.vb.beaconP2Count) -- (15.2 outlier) 21.1-22.1
			else
				timerNextBeacon:Start(nil, self.vb.beaconP2Count)
			end
			if self.Options.SetIconOnFrostBeacon then
				self:SetIcon(args.destName, 8)
				if self.Options.AnnounceFrostBeaconIcons and DBM:IsInGroup() and DBM:GetRaidRank() > 1 then
					SendChatMessage(L.BeaconIconSet:format(8, args.destName), DBM:IsInRaid() and "RAID" or "PARTY")
				end
			end
			warnBeaconTargets(self)
		else--Phase 1 air phase, multiple beacons
			local maxBeacon = self:IsDifficulty("heroic25") and 6 or self:IsDifficulty("normal25") and 5 or 2--Heroic 10 and normal 2 are both 2
			if self.Options.SetIconOnFrostBeacon then
				self:SetUnsortedIcon(0.3, args.destName, 1, maxBeacon, false, "AnnounceBeaconIcons") -- Unsorted, to match CLEU order, which is the one used for announce object. Roster sorting makes icons not reproducible
			end
			self:Unschedule(warnBeaconTargets)
			if #beaconTargets >= maxBeacon then
				warnBeaconTargets(self)
			else
				self:Schedule(0.3, warnBeaconTargets, self)
			end
		end
	elseif spellId == 69762 then
		unchainedTargets[#unchainedTargets + 1] = args.destName
		if args:IsPlayer() then
			playerUnchained = true
			specWarnUnchainedMagic:Show()
			specWarnUnchainedMagic:Play("targetyou")
			soundUnchainedMagic:Play("Interface\\AddOns\\DBM-Core\\sounds\\RaidAbilities\\unchained.mp3")
		end
		if self.Options.SetIconOnUnchainedMagic then
			self:SetIcon(args.destName, self.vb.unchainedIcons)
		end
		self.vb.unchainedIcons = self.vb.unchainedIcons + 1
		self:Unschedule(warnUnchainedTargets)
		if #unchainedTargets >= 6 then
			warnUnchainedTargets(self)
		else
			self:Schedule(0.3, warnUnchainedTargets, self)
		end
	elseif spellId == 70106 then	--Chilled to the bone (melee)
		if args:IsPlayer() then
			timerChilledtotheBone:Start()
			if (self:IsHeroic() and (args.amount or 1) >= 4) or (args.amount or 1) >= 8 then
				specWarnChilledtotheBone:Show(args.amount)
				specWarnChilledtotheBone:Play("stackhigh")
			else
				warnChilledtotheBone:Show(args.amount or 1)
			end
		end
	elseif spellId == 69766 then	--Instability (casters)
		if args:IsPlayer() then
			timerInstability:Start()
			if (self:IsHeroic() and (args.amount or 1) >= 4) or (args.amount or 1) >= 8 then
				specWarnInstability:Show(args.amount)
				specWarnInstability:Play("stackhigh")
			else
				warnInstability:Show(args.amount or 1)
			end
		end
	elseif args:IsSpellID(70127, 72528, 72529, 72530) then	--Mystic Buffet (phase 2 - everyone)
		if args:IsPlayer() then
			timerMysticBuffet:Start()
--			timerNextMysticBuffet:Start()
			if (args.amount or 1) >= 5 then
				specWarnMysticBuffet:Show(args.amount)
				specWarnMysticBuffet:Play("stackhigh")
			else
				warnMysticBuffet:Show(args.amount or 1)
			end
			if self.Options.AchievementCheck and not self.vb.warnedfailed and (args.amount or 1) < 2 then
				timerMysticAchieve:Start()
			end
		end
		if args:IsDestTypePlayer() then
			if self.Options.AchievementCheck and DBM:GetRaidRank() > 0 and not self.vb.warnedfailed and self:AntiSpam(3) then
				if (args.amount or 1) == 5 then
					SendChatMessage(L.AchievementWarning:format(args.destName), "RAID")
				elseif (args.amount or 1) > 5 then
					self.vb.warnedfailed = true
					SendChatMessage(L.AchievementFailed:format(args.destName, (args.amount or 1)), "RAID_WARNING")
				end
			end
			if self:AntiSpam(5, 2) then -- real time correction if any raid member receives the debuff in a 5 second window
				self:Unschedule(cycleMysticBuffet)
				cycleMysticBuffet(self)
			end
		end
	end
end
mod.SPELL_AURA_APPLIED_DOSE = mod.SPELL_AURA_APPLIED

function mod:SPELL_AURA_REMOVED(args)
	local spellId = args.spellId
	if spellId == 69762 then
		if self.Options.SetIconOnUnchainedMagic then
			self:SetIcon(args.destName, 0)
		end
	elseif spellId == 70157 then
		if self.Options.SetIconOnFrostBeacon then
			self:SetIcon(args.destName, 0)
		end
	elseif spellId == 70106 then	--Chilled to the bone (melee)
		if args:IsPlayer() then
			timerChilledtotheBone:Cancel()
		end
	elseif spellId == 69766 then	--Instability (casters)
		if args:IsPlayer() then
			timerInstability:Cancel()
		end
	elseif args:IsSpellID(70127, 72528, 72529, 72530) then
		if args:IsPlayer() then
			timerMysticAchieve:Cancel()
			timerMysticBuffet:Cancel()
		end
	end
end

function mod:UNIT_HEALTH(uId)
	if not self.vb.warned_P2 and self:GetUnitCreatureId(uId) == 36853 and UnitHealth(uId) / UnitHealthMax(uId) <= 0.38 then
		self.vb.warned_P2 = true
		warnPhase2soon:Show()
	end
end

--[[ On Bennu, UNIT_TARGET needs review to check if it fires on landing. UNIT_TARGET only fires if Sindragosa is targeted or focused (sync'ed below)
function mod:UNIT_TARGET(uId)
	if self:GetUnitCreatureId(uId) ~= 36853 then return end
	-- Attempt to catch when she lands by checking for Sindragosa's target being a raid member
	if UnitExists(uId.."target") then
		self:SendSync("SindragosaLanded") -- Sync landing with raid since UNIT_TARGET event requires Sindragosa to be target/focus, which not all members do
	end
end
]]

function mod:CHAT_MSG_MONSTER_YELL(msg)
	if (msg == L.YellAirphase or msg:find(L.YellAirphase)) or (msg == L.YellAirphaseDem or msg:find(L.YellAirphaseDem)) then
		if self.Options.ClearIconsOnAirphase then
			self:ClearIcons()
		end
		self:SetStage(1.5)
		warnAirphase:Show()
		timerNextFrostBreath:Cancel()
		timerUnchainedMagic:Cancel()
		timerNextBlisteringCold:Cancel()
		timerTailSmash:Cancel()
		timerNextGroundphase:Start()
		warnGroundphaseSoon:Schedule(41)
		self:Schedule(46, landingPhaseWorkaround, self) -- 0.1s leeway from lowest seen timer
--		self:RegisterShortTermEvents(
--			"UNIT_TARGET"
--		)
	elseif (msg == L.YellPhase2 or msg:find(L.YellPhase2)) or (msg == L.YellPhase2Dem or msg:find(L.YellPhase2Dem)) then
		self:SetStage(2)
		warnPhase2:Show()
		warnPhase2:Play("ptwo")
		timerNextBeacon:Start(7.9, 1) -- no need to use self.vb.beaconP2Count here since it will always be one on this timer. ~2s variance [7.9-9.7] (25N Bennu [2023-06-03]@[20:22:52] || 25H Bennu [2023-06-08]@[21:15:19] || 10N Bennu [2023-06-09]@[16:21:59] || 25H Bennu [2023-06-29]@[23:19:27] || 10H Bennu [2023-07-08]@[23:48:34]) - 8.1 || 7.9 || 9.5 || 9.2 || 9.7
		timerNextAirphase:Cancel()
		timerNextGroundphase:Cancel()
		warnGroundphaseSoon:Cancel()
		timerNextBlisteringCold:Restart(35.2) -- (25N Bennu [2023-06-03]@[20:22:52] || 25H Bennu [2023-06-08]@[21:15:19] || 10N Bennu [2023-06-09]@[16:21:59] || 25H Bennu [2023-06-29]@[23:19:27] || 10H Bennu [2023-07-08]@[23:48:34]) - 36.8 || 36.6 || 39.6 || 35.2 || 37.0
		timerNextMysticBuffet:Start(6)
		self:Schedule(6, cycleMysticBuffet, self)
		self:Unschedule(landingPhaseWorkaround)
--		self:UnregisterShortTermEvents() -- REVIEW! not sure it's needed, but doesn't hurt. Would need validation on event order when boss is intermissioned with health right above phase 2 threshold, to check which of the events come first (TARGET or YELL)
	end
end

--[[function mod:OnSync(msg)
	if not self:IsInCombat() then return end
	if msg == "SindragosaLanded" and self:GetStage(1.5) then
		self:Unschedule(landingPhaseWorkaround)
		self:SetStage(1)
		timerNextAirphase:Start()
		timerUnchainedMagic:Start(10) -- (10H Lordaeron 2022/10/02 || 25H Lordaeron 2022/10/02) - 10.0; 10.0 || 10.0; 10.0, 10.0; 10.0
		timerTailSmash:Start(19) -- ~5s variance [19-23.8]? (10N Icecrown 2022/08/25 || 10H Lordaeron 2022/10/02 || 25H Lordaeron 2022/10/02) - 19.0 || 21.4; 21.9 || 21.4; 23.8, 22.6; 22.2
		timerNextBlisteringCold:Start(34) -- 6s variance [34-40]? (10H Lordaeron 2022/10/02 || 25H Lordaeron 2022/10/02) - 34.0; 34.0 || 34.0; 34.0; 34.0
		self:UnregisterShortTermEvents()
	end
end]]
